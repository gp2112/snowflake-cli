# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['snowflakecli']

package_data = \
{'': ['*']}

install_requires = \
['requests==2.27.0', 'selenium==4.1.2']

setup_kwargs = {
    'name': 'snowflakecli',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'gp2112',
    'author_email': 'me@guip.dev',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
